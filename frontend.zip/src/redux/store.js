import {crateStore} from "redux"


const store= crateStore(
    
)