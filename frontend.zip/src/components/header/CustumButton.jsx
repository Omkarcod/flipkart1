import { Box, Button, Typography, styled } from "@mui/material";
import React from "react";
import ShoppingCartIcon from "@mui/icons-material/ShoppingCart";
import { useState, useContext } from "react";

// components import
import LoginDialog from "../login/LoginDialog";
import { Datacontext } from "../context/DataProvider.jsx";
import Profile from "./Profile.jsx";

// styling using styled component=>

const Wrapper = styled(Box)`
  display: flex;
  /* justify-content: space-around; */
  align-items: center;
  margin: 0 3% 0 auto;
  & > button,
  & > p,
  & > div {
    margin-right: 40px;
    font-size: 16px;
  }
`;

const CartDiv = styled(Box)`
  display: flex;
`;
const ButtonStyle = styled(Button)`
  color: blue;
  background: #fff;
  text-transform: none;
  padding: 5px 40px;
  border-radius: 5px;
  box-shadow: none;
  /* margin-left: 15px; */
  font-weight: 600;
  height: 32px;
`;

const CustumButton = () => {
  const [open, setOpen] = useState(false);
  const { account,setAccount } = useContext(Datacontext);
  // Logical function
  const openDialog = () => {
    setOpen(true);
  };
  return (
    <Wrapper>
      {
        account ? <Profile account={account} setAccount={setAccount}/> : 
      <ButtonStyle variant="contained" onClick={() => openDialog()}>
        Login
      </ButtonStyle>
      }
      <Typography style={{ marginTop: 3, width: 135 }}>
        Become a Seller
      </Typography>
      <Typography style={{ marginTop: 3 }}>More</Typography>

      <CartDiv>
        <ShoppingCartIcon />
        <Typography>Cart</Typography>
      </CartDiv>
      <LoginDialog open={open} setOpen={setOpen} />
    </Wrapper>
  );
};

export default CustumButton;
