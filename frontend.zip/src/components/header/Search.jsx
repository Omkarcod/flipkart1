import React from "react";
import SearchIcon from "@mui/icons-material/Search";
import { InputBase, Box, styled } from "@mui/material";

// styling using styled components
const SearchContainer = styled(Box)`
  background-color: white;
  width: 38%;
  border-radius: 5px;
  margin-left: 10px;
  display: flex;
  `;
const InputContainer = styled(InputBase)`
  /* background-color: white; */
  color: grey;
  margin-left: 20px;
  width: 100%;
  font-size: unset;
`;
const SearchIconWrapper = styled(Box)`
  color: blue;
  padding: 5px;
  display: flex;
  cursor: pointer;
`;
const Search = () => {
  return (
    <SearchContainer>
      <InputContainer placeholder="Search for Products,Brands and More" />
      <SearchIconWrapper>
        <SearchIcon />
      </SearchIconWrapper>
    </SearchContainer>
  );
};

export default Search;
